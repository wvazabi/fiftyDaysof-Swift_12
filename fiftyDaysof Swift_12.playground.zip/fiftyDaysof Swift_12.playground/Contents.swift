import UIKit
import Foundation
import Darwin

var greeting = "Hello, playground"

protocol AProtocol {
    
    var a: String? {get set}
    
    func aProtocolFunc(_ element1: String, _ element2: String)
}

protocol BProtocol {
    
    var b: String? {get set}
    
    func bProtocolFunc(_ element1: String, _ element2: String)
}

extension AProtocol {
    func aProtocolFunc(_ element1: String, _ element2: String){
        print("asd")
    }
}

class X: AProtocol {
   
    var a: String?
    
}

class A: AProtocol,BProtocol {
   
    var b: String?
    
    func bProtocolFunc(_ element1: String, _ element2: String) {
        <#code#>
    }
    
    
    var a: String?
    
    func aProtocolFunc(_ element1: String, _ element2: String) {
        print("Class A")
    }
}

class B: AProtocol {
    var a: String?
    
    func aProtocolFunc(_ element1: String, _ element2: String) {
        print("Class B")
    }
    
    
}

class C: BProtocol {
    var b: String?
    
    func bProtocolFunc(_ element1: String, _ element2: String) {
        <#code#>
    }
    
    
    
}


var objectA = A()
var objectB = B()

var array: [AProtocol] = []

array.append(objectA)
array.append(objectB)

var protocolObject: AProtocol

var testObject: A

protocolObject = objectA
protocolObject = objectB


class RadioCenter {
    
    init() {
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
           
            let userInfo : [String:String] = ["music":"Demet Akalın"]
            NotificationCenter.default.post(
                name: .init(rawValue: "Eksen FM 96.2"),
                object: nil,
                userInfo: userInfo
            )
        }
        
    }
    
}

class Mercedes {
    init() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(play(_:)),
            name: .init(rawValue: "Eksen FM 96.2"),
            object: nil
        )
    }
    
    @objc
    private func play(_ notification: NSNotification){
        let music = (notification.userInfo as! [String:String]) ["music"]!
        print("playing \(music)")
    }
    
}

var gWagon = Mercedes()
var radio = RadioCenter()






